package com.capgemini.bank.service;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;


public interface IDemandDraftService {

	boolean validateDemandDraftDetails(DemandDraft bean) throws DemandDraftException;

	int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, DemandDraftException;

	boolean validatetransactionId(int transaction_id);

	DemandDraft getDemandDraftDetails(int transaction_id) throws DemandDraftException;
}
