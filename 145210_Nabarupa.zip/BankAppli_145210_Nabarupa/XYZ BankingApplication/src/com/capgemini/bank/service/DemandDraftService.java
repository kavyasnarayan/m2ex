package com.capgemini.bank.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftException;


public class DemandDraftService implements IDemandDraftService {


	public boolean validateDemandDraftDetails(DemandDraft bean)
			throws DemandDraftException {
		String errorMessage = "";
		String customer_name;
		String phone_number ;
		 String dd_amount;

		// Validating name
		
		 customer_name=bean.getCustomer_name();
		Pattern namePattern = Pattern.compile("^[A-Z][a-z]{3,20}$");
		Matcher nameMatcher = namePattern.matcher(customer_name);

		if (!(nameMatcher.matches())) {
			errorMessage+="\nName Should Be In alphabets only and first letter [A-Z].";
		}


		// Validating Phone Number
		phone_number = bean.getPhone_number();

		Pattern phonePattern = Pattern.compile("^\\d{10}$");
		Matcher phoneMatcher = phonePattern.matcher(phone_number);

		if (!(phoneMatcher.matches())) {
			errorMessage+="\nPhone Number must contain 10 digit";

		}

		// Validating Amount
		dd_amount = bean.getDd_amount()+"";
		Pattern amountPattern = Pattern.compile("^([0-9]*[.])?[0-9]{1}+$");
		Matcher amountMatcher = amountPattern.matcher(dd_amount);

		if (!(amountMatcher.matches())) {
			errorMessage+="\nAmount Should take only 1 decimal digit";

		}
	
        if(!errorMessage.isEmpty())
            throw new DemandDraftException(errorMessage);
        else
		return false;
	}

     //Adding Demand Draft Details
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, DemandDraftException {
	  IDemandDraftDAO dao=new DemandDraftDAO();
	  double Amt= demandDraft.getDd_amount();
	 int amount=(int) Amt;
	  int comm;
	  
	  if(amount>0 && amount<=5000){
		  comm=10;
		  demandDraft.setDd_commission(comm);
	  }
	  else if(amount>=5001 && amount<=10000){
		  comm=41;
		  demandDraft.setDd_commission(comm);
	  }
	  else if(amount>=10001 && amount<=100000){
		  comm=51;
		  demandDraft.setDd_commission(comm);
	  }
	  else if(amount>=100001 && amount<=500000){
		  comm=306;
		  demandDraft.setDd_commission(comm);
	  }
	  
	 
	  int transacID = dao.addDemandDraftDetails(demandDraft);
	  
		return transacID;
	}

          // validating transaction ID
	public boolean validatetransactionId(int transaction_id) {
		String transac_id=transaction_id+"";
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(transac_id);
		
		if(idMatcher.matches())
			return true;
		else
			return false;	
	}

       //Getting Demand Draft Details
	public DemandDraft getDemandDraftDetails(int transaction_id) throws DemandDraftException {
		DemandDraft demandDraft=null;
		IDemandDraftDAO dao=new DemandDraftDAO();
		demandDraft=dao.getDemandDraftDetails(transaction_id);
		 double total_amount=((demandDraft.getDd_commission())+(demandDraft.getDd_amount()));
		  demandDraft.setTotal_amount(total_amount);
		return demandDraft;
	}

}
