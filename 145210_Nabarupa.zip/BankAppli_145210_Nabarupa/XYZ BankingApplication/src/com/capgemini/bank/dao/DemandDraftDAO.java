package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;
import com.capgemini.bank.util.DBConnection;




public class DemandDraftDAO implements IDemandDraftDAO , QueryMapping{
    private static final Logger LOGGER=Logger.getLogger(DemandDraftDAO.class);

	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, DemandDraftException {
		 
			
					int result=1;
					int transac_id = 0;
					Connection connection=null;
					PreparedStatement preparedStatement=null;
					PreparedStatement preparedStatement1 = null;
					ResultSet resultSet= null;
					try {
						LOGGER.info("Calling getConnection to esatblish DB Connection");
						connection=DBConnection.getConnection();
						LOGGER.warn("inserting the data through insert query");
						preparedStatement=connection.prepareStatement(QueryMapping.INSERT_QUERY);
						preparedStatement.setString(1, demandDraft.getCustomer_name());
						preparedStatement.setString(2,demandDraft.getIn_favor_of());
						preparedStatement.setString(3, demandDraft.getPhone_number());
						preparedStatement.setDouble(4, demandDraft.getDd_amount());
						preparedStatement.setInt(5, demandDraft.getDd_commission());
						preparedStatement.setString(6, demandDraft.getDd_description());
						result= preparedStatement.executeUpdate();
						LOGGER.warn("Checking the current value of transaction id through current val query");
						preparedStatement1=connection.prepareStatement(QueryMapping.transactionid_QUERY_SEQUENCE);
						resultSet=preparedStatement1.executeQuery();
						if(resultSet.next()){
							transac_id=resultSet.getInt(1);
							
						}
						
					} 	finally
					{
						try 
						{
							LOGGER.warn("Closing the resultset,preapred statement");
							resultSet.close();
							preparedStatement.close();
							preparedStatement1.close();
//							connection.close();
						} 
						catch (SQLException e) 
						{   LOGGER.fatal("Problem in closing DB Connection");
							throw new DemandDraftException("Error in closing db connection");

						}
					}
					if(result==0){
						LOGGER.warn("Insertion Failed");
						throw new DemandDraftException("Insertion Failed");
					} 
		return transac_id;
	}


	public DemandDraft getDemandDraftDetails(int transaction_id) throws DemandDraftException {
		DemandDraft demandDraft=new DemandDraft();
		Connection connection=DBConnection.getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		
		try
		{          LOGGER.info("Query for View student");    
			preparedStatement=connection.prepareStatement(QueryMapping.VIEW_STUDENT_DETAILS_QUERY);
			preparedStatement.setInt(1,transaction_id);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{  LOGGER.warn("loading data for view details");
				demandDraft=new DemandDraft();
				demandDraft.setDd_amount(resultset.getDouble(1));
				demandDraft.setDd_commission(resultset.getInt(2));
				demandDraft.setDd_description(resultset.getString(3));
				
			}
			
			LOGGER.info("returning DemandDraft demandDraft");
				return demandDraft;
			
		
			
		}
		catch(Exception expression)
		{
			throw new DemandDraftException(expression.getMessage());
		}
		finally
		{
			try 
			{  LOGGER.warn("Closing the resultset,preapred statement");
				resultset.close();
				preparedStatement.close();
//				connection.close();
			} 
			catch (SQLException connection1) 
			{ LOGGER.fatal("Problem in closing DB Connection");
				throw new DemandDraftException("Error in closing db connection");

			}
		}
	}

}
