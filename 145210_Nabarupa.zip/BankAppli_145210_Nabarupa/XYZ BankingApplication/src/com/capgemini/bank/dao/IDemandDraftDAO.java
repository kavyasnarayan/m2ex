package com.capgemini.bank.dao;

import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;

public interface IDemandDraftDAO {



	int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException, DemandDraftException;

	DemandDraft getDemandDraftDetails(int transaction_id) throws DemandDraftException;

}
