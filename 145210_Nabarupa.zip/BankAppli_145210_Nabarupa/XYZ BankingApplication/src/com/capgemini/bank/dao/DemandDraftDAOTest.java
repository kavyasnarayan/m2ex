package com.capgemini.bank.dao;




import java.sql.SQLException;
import java.util.List;





import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;

import junit.framework.TestCase;

public class DemandDraftDAOTest extends TestCase {
 IDemandDraftDAO dao;
	protected void setUp() throws Exception {
	 dao= new DemandDraftDAO();
	}

	public void testAddDemandDraftDetails() throws SQLException {
		DemandDraft demandDraft = new DemandDraft();
		demandDraft.setCustomer_name("King");
		demandDraft.setPhone_number("9087654321");
		demandDraft.setDd_amount(56000);
		
		try {
			int transaction_id=dao.addDemandDraftDetails(demandDraft);
			assertEquals(10012, transaction_id);
		} catch (DemandDraftException excep) {
			fail(" exception occured "+excep.getMessage());
		}
	}

	

	public void testGetDemandDraftDetails() {
		DemandDraft demandDraft = new DemandDraft();
		DemandDraft demandDraft1 = new DemandDraft();
		demandDraft.getDd_amount();
		demandDraft.getDd_commission();
		demandDraft.getTotal_amount();
		demandDraft.getDd_commission();
		int transaction_id=demandDraft.getTransaction_id();
		try {
			demandDraft1= dao.getDemandDraftDetails(transaction_id);
			assertNotSame(demandDraft, demandDraft1);
			
		} catch (DemandDraftException exception) {
			fail(" exception occured "+exception.getMessage());
		}
		
	}

}
