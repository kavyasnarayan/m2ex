package com.capgemini.bank.exception;

public class DemandDraftException extends Exception{

	public DemandDraftException(String message) {
		super(message);
	}

	

}
