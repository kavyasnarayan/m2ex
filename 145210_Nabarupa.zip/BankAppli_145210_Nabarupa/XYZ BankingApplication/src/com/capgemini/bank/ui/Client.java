package com.capgemini.bank.ui;


import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;




public class Client {
   
	
	
	public static void main(String[] args) throws SQLException, DemandDraftException {
         IDemandDraftService draftService= new DemandDraftService();
		 DemandDraft demandDraft=new DemandDraft();
	       String option;
	       String decision;
	       int transaction_id;
		   String customer_name;
		   String in_favor_of; 
		   String phone_number ;
		   double dd_amount;
		   String dd_description ;

	       Scanner scanner= new Scanner(System.in);
	       do{
	           System.out.println("1.Enter Demand Draft Details");
	           System.out.println("2.Print Demand draft");
	           System.out.println("3.Exit");
	           System.out.println("Enter your choice(1-3)");
	           option=scanner.next();
	           
	           switch(option)
	           { 
	           case "1":
	                System.out.println("Enter Demand Draft Details");
	             	  
	                System.out.println("Enter the name of the customer :");
	             	customer_name=scanner.next();
	             	demandDraft.setCustomer_name(customer_name);
	           	   
	             	System.out.println("Enter customer phone number:");
	             	phone_number=scanner.next();
	            	demandDraft.setPhone_number(phone_number) ;
	            	
	            	System.out.println("In favor of:");
	            	in_favor_of=scanner.next();
	               	demandDraft.setIn_favor_of(in_favor_of) ;
	            	
	               	System.out.println("Enter Demand Draft amount(in Rs):");
	               	dd_amount=scanner.nextDouble();
	               	demandDraft.setDd_amount( dd_amount) ;
	               	
	             	System.out.println("Enter Remarks:");
	             	dd_description=scanner.next();
	               	demandDraft.setDd_description(dd_description) ;
	               	
	           

	                try 
	                {           
	                                if(draftService.validateDemandDraftDetails(demandDraft)==true){
	                                                System.out.println("invalid data");
	                                }
	                                else{
	                                	
	                                	transaction_id=draftService.addDemandDraftDetails(demandDraft);
	                               	  System.out.println("Your Demand Draft request has been successfuly registered along with "+ transaction_id);
	                                }
	                } 
	                catch (DemandDraftException e) 
	                {
	                                System.err.println(e.getMessage() + ", try again");
	                }

	               
	            
	                 break;
	           
	           case "2":

					System.out.println("Enter the TranscationID ");
					transaction_id = scanner.nextInt();

				if(draftService.validatetransactionId(transaction_id)==true){
				                System.out.println("invalid transaction_id ");
				}
				else{
					
					 demandDraft = draftService.getDemandDraftDetails(transaction_id);
						if (demandDraft != null) {
							System.out.println("Name of the bank: XYZ");
							System.out.println("DD Amount		:"
									+ demandDraft.getDd_amount());
							System.out.println("DD commission :"
									+ demandDraft.getDd_commission());
							System.out.println("Total Amount:"
									+ demandDraft.getTotal_amount());
							System.out.println("Reamrks:"
									+demandDraft.getDd_description());
						} else {
							System.err
									.println("There are no donation details associated with donor id "
											+ transaction_id);
						
				}
            }
	               
				   break;

	              
	           
	           case "3":
					break;

	                 
	           default:
	                 System.out.println("Please select between 1-3");
	                 break;
	           }
	           System.out.println("Do you want to continue further(yes/no)?");
	           decision=scanner.next();
	    }while(decision.equals("yes"));
	       scanner.close(); 
	       
		}
	}


