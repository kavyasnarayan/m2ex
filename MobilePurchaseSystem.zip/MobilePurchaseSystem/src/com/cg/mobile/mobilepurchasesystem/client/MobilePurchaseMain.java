package com.cg.mobile.mobilepurchasesystem.client;


import java.util.Date;
import java.util.Scanner;

import com.cg.mobile.mobilepurchasesystem.bean.PurchaseDetails;
import com.cg.mobile.mobilepurchasesystem.exception.MobileException;
import com.cg.mobile.mobilepurchasesystem.service.IMobileService;
import com.cg.mobile.mobilepurchasesystem.service.MobileServiceImpl;

public class MobilePurchaseMain {

	public static void main(String[] args) {
       IMobileService iMobileService= new MobileServiceImpl();
       PurchaseDetails purchaseDetails= new PurchaseDetails();
       String option;
       String decision;
    	// int purchaseID ;
    	 String cname;
   	     String mobileID;
   	     String mailid; 
     	 String phoneno ;
     	// Date purchasedate;
       Scanner scanner= new Scanner(System.in);
       do{
           System.out.println("1.Insert customer and purchase details");
           System.out.println("2.Updated the mobile quantity");
           System.out.println("3.View all mobile details");
           System.out.println("4.exit");
           System.out.println("Enter your choice(1-4)");
           option=scanner.next();
           
           switch(option)
           { 
           case "1":
                System.out.println("Add customer and purchase details");
             	  System.out.println("Enter Customer name");
             	 cname=scanner.next();
             	purchaseDetails.setCname(cname);
           	   
             	System.out.println("Enter Customer MailID");
           	    mailid=scanner.next();
            	purchaseDetails.setMailid(mailid) ;
            	
            	System.out.println("Enter Customer phoneno");
            	phoneno=scanner.next();
               	purchaseDetails.setPhoneno(phoneno) ;
            	
               	System.out.println("Enter mobile Id");
               	mobileID=scanner.next();
               	purchaseDetails.setMobileID(mobileID) ;
               	
           

                try 
                {           
                                if(iMobileService.validateMobileDetails(purchaseDetails)==false){
                                                System.out.println("invalid data");
                                }
                                else{
                                	iMobileService.addPurchaseDetails(purchaseDetails);
                               	 
                                }
                } 
                catch (MobileException e) 
                {
                                System.err.println(e.getMessage() + ", try again");
                }

               
            
                 break;
           
           case "2":
      

                 break;
           
           case "3":


				break;
               
                 
           case "4":
                 break;
                 
           default:
                 System.out.println("Please select between 1-4");
                 break;
           }
           System.out.println("Do you want to continue further(Yes/No)?");
           decision=scanner.next();
    }while(decision.equals("yes"));
       scanner.close(); 
       
	}

}
