package com.cg.mobile.mobilepurchasesystem.bean;

import java.util.Date;

public class PurchaseDetails {
	private int purchaseID ;
	private String cname;
	private String mobileID;
	private String mailid; 
	private String phoneno ;
	private Date purchasedate;
	public int getPurchaseID() {
		return purchaseID;
	}
	public void setPurchaseID(int purchaseID) {
		this.purchaseID = purchaseID;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMobileID() {
		return mobileID;
	}
	public void setMobileID(String mobileID) {
		this.mobileID = mobileID;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public Date getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseID=" + purchaseID + ", cname=" + cname
				+ ", mobileID=" + mobileID + ", mailid=" + mailid
				+ ", phoneno=" + phoneno + ", purchasedate=" + purchasedate
				+ "]";
	}

	
	
}
