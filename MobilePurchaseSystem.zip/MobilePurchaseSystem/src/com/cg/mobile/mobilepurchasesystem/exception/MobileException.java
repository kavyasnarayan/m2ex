package com.cg.mobile.mobilepurchasesystem.exception;

public class MobileException extends Exception {

	public MobileException(String message) {
		super(message);
		
	}

}
