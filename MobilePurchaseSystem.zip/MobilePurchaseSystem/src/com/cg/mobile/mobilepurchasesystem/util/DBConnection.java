package com.cg.mobile.mobilepurchasesystem.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
	static Connection connection;
	public static Connection getConnection() {
		
	    if(connection==null){
		
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			 InputStream inputStream = new FileInputStream("resources/jdbc.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			String url= properties.getProperty("url");
			String user=properties.getProperty("user");
			String password = properties.getProperty("password");
			inputStream.close();
			connection = DriverManager.getConnection(url,user,password);
		}
		catch (FileNotFoundException e1) {
		
			e1.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return connection;
		
		
		
	    }
	    else
	    	return connection;
	}

}
