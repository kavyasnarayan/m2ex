package com.cg.mobile.mobilepurchasesystem.service;

import com.cg.mobile.mobilepurchasesystem.bean.PurchaseDetails;
import com.cg.mobile.mobilepurchasesystem.exception.MobileException;

public interface IMobileService {

	boolean validateMobileDetails(PurchaseDetails bean) throws MobileException;

	void addPurchaseDetails(PurchaseDetails purchaseDetails) throws MobileException;
}
