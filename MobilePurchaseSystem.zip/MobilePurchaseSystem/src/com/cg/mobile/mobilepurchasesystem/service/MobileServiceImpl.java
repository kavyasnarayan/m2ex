package com.cg.mobile.mobilepurchasesystem.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mobile.mobilepurchasesystem.bean.PurchaseDetails;
import com.cg.mobile.mobilepurchasesystem.dao.IMobileDao;
import com.cg.mobile.mobilepurchasesystem.dao.MobileDaoImpl;
import com.cg.mobile.mobilepurchasesystem.exception.MobileException;


public class MobileServiceImpl implements IMobileService{
	public boolean validateMobileDetails(PurchaseDetails bean) throws MobileException {
		String errorMessage = "";
		String Name = null;
		String phoneNumber = null;
		String mobileID;

		// Validating name
		
		Name=bean.getCname();
		Pattern namePattern = Pattern.compile("^[A-Z][a-z]{3,20}$");
		Matcher nameMatcher = namePattern.matcher(Name);

		if (!(nameMatcher.matches())) {
			errorMessage+="\nName Should Be In Alphabets and minimum 3 and maximum 20 characters long.";
		}

		//Validating mailID
		String MailId = bean.getMailid();
		Pattern mailIdPattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		Matcher mailIdMatcher = mailIdPattern.matcher(MailId);

		if (!(mailIdMatcher.matches())) {
			errorMessage+="\nEmail id is not valid";
		}

		// Validating Phone Number
		phoneNumber = bean.getPhoneno();

		Pattern phonePattern = Pattern.compile("^\\d{10}$");
		Matcher phoneMatcher = phonePattern.matcher(phoneNumber);

		if (!(phoneMatcher.matches())) {
			errorMessage+="\nPhone Number Should be in 10 digit";

		}

		// Validating MobileId
		mobileID = bean.getMobileID();
		Pattern mobileIDPattern = Pattern.compile("^\\d{4}$");
		Matcher mobileIDMatcher = mobileIDPattern.matcher(mobileID);

		if (!(mobileIDMatcher.matches())) {
			errorMessage+="\nMobile ID Should be in 4 digit";

		}
	
        if(!errorMessage.isEmpty())
            throw new MobileException(errorMessage);
        else
     return true;
     

	}
	public void addPurchaseDetails(PurchaseDetails bean) throws MobileException{
		IMobileDao dao= new MobileDaoImpl();
		dao.addPurchasedetails(bean);
		
	}
}
