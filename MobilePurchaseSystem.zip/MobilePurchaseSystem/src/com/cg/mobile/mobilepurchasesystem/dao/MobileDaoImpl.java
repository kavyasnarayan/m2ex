package com.cg.mobile.mobilepurchasesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.mobile.mobilepurchasesystem.bean.PurchaseDetails;
import com.cg.mobile.mobilepurchasesystem.exception.MobileException;
import com.cg.mobile.mobilepurchasesystem.util.DBConnection;


public class MobileDaoImpl implements IMobileDao {


	@SuppressWarnings("resource")
	public void addPurchasedetails(PurchaseDetails bean) throws MobileException {
	
	
			int result=1;
			int result1=0;
			String purchaseId=null;
			Connection connection=null;
			PreparedStatement preparedStatement=null;
			ResultSet resultSet= null;
			try {
				connection=DBConnection.getConnection();
				PreparedStatement count=connection.prepareStatement(QueryMapper.COUNT_QUERY);
				count.setString(1, bean.getMobileID());
				result1= count.executeUpdate();
				if(result1>0){
				preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
				preparedStatement.setString(1, bean.getCname());
				preparedStatement.setString(2,bean.getMailid());
				preparedStatement.setString(3, bean.getPhoneno());
				preparedStatement.setString(4, bean.getMobileID());
				result= preparedStatement.executeUpdate();
				 preparedStatement =connection.prepareStatement(QueryMapper.purchaseid_QUERY_SEQUENCE);
				resultSet=preparedStatement.executeQuery();
				if(resultSet.next()){
					purchaseId=resultSet.getString(1);
					
				}
				}
				else{
					throw new MobileException("Mobile quantity is less that zero");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}	finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
//					connection.close();
				} 
				catch (SQLException e) 
				{
					throw new MobileException("Error in closing db connection");

				}
			}
			if(result==0){
				throw new MobileException("Insertion Failed");
			} 
		}
			
	}


