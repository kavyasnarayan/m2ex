package com.cg.mobile.mobilepurchasesystem.dao;

import com.cg.mobile.mobilepurchasesystem.bean.PurchaseDetails;
import com.cg.mobile.mobilepurchasesystem.exception.MobileException;

public interface IMobileDao {

	void addPurchasedetails(PurchaseDetails bean) throws MobileException;
      
}
