package com.cg.mobile.mobilepurchasesystem.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid) VALUES(purchaseid_sequence.NEXTVAL,?,?,?,SYSDATE,?)";
	public static final String purchaseid_QUERY_SEQUENCE="SELECT purchaseid_sequence.CURRVAL FROM DUAL";
	public static final String COUNT_QUERY="SELECT quantity FROM mobiles where mobileid=?";
}
